---
name: hr-dashboard
description: Generate, update, export, and share the single-file HR dashboard in this repository using the established ECharts 5 design system, page layout, CSV export rules, edit-password workflow, and share-page synchronization process. This skill should be used when the user provides new HR data or asks to modify the existing dashboard.
---

# HR Dashboard

## Overview
Generate and iteratively modify the HR dashboard in this repository. Prioritize in-place updates to `hr_dashboard.html`, keep `hr_dashboard_share.html` identical, and preserve the established visual language, page structure, CSV export behavior, and share workflow.

## Use this skill when
- Importing new HR, recruiting, or product-line data from Excel, CSV, or manual notes
- Adjusting KPIs, charts, table fields, or page layout
- Fixing tab switching, lazy chart rendering, CSV export, table rendering, or permission behavior
- Refreshing the share page or publishing a new 72-hour share link
- Reproducing the same dashboard style in a new iteration

## Core workflow
1. Read `references/maintenance-and-share.md` for file map, sync rules, validation steps, and share upload steps.
2. Read `references/style-and-layout.md` before changing visual style or page layout.
3. Read `references/data-and-charts.md` before touching DB fields, chart logic, filters, or exports.
4. Modify `hr_dashboard.html` in place unless the user explicitly asks for a new file.
5. Sync `hr_dashboard_share.html` so that both files stay identical.
6. Validate the result:
   - inline script syntax check
   - table, chart, and page-switch behavior check
   - main/share equality check
   - preview the HTML when a user-facing result is ready
7. Publish a new 72-hour link only when the user asks for sharing.

## Guardrails
- Keep the dashboard as a single-file HTML + ECharts 5 + Vanilla JS artifact.
- Preserve the three-theme loop: `dark → light → blue`.
- Preserve page IDs and navigation: `overview`, `recruit`, `product`, `manage`.
- Keep `overview` and `manage` outside the business-group filter bar.
- Keep the edit flow as: view without login → verify password before editing.
- Keep the header page-level CSV export button and manage-page category exports.
- On the product page, export the currently filtered business-group data.
- Preserve the “manual value first, auto-fallback from offerList” rule for overseas onboarding.
- Do not add scanline animation, `最后更新时间`, `数据来源`, black borders, or duplicate KPI cards.
- For ECharts funnel labels, force transparent label background and border.

## Reference map
- `references/style-and-layout.md` — visual language, theme tokens, page structure, forbidden patterns
- `references/data-and-charts.md` — data domains, page modules, charts, filter behavior, export rules
- `references/maintenance-and-share.md` — file map, permission model, sync, validation, packaging, 72-hour upload

## Expected outputs
- Updated `hr_dashboard.html`
- Identical `hr_dashboard_share.html`
- If requested, a refreshed 72-hour public link
- Optional package zip for distribution
