# Style and Layout Reference

## Theme system
- Theme cycle: `dark → light → blue`
- Theme button emoji: `🌙 / ☀️ / 🩵`
- Preferred base colors:
  - dark: `#060f20`
  - light: `#f5f7ff`
  - blue: `#f6f9fc` with Zhihu blue `#0066cc`

## Visual language
- Use glass-card panels with soft glow, rounded corners, and spacious padding.
- Keep emoji in section titles and chart titles.
- Use ECharts 5 from CDN.
- For funnel labels, set `backgroundColor:'transparent'`, `borderWidth:0`, `borderColor:'transparent'`.
- Edit button stays transparent by default, appears only when the parent card is hovered, and shows only the `✏️` emoji.

## Do not add
- Scanline animation
- `最后更新时间`
- `数据来源`
- Black borders
- Duplicate KPI cards

## Current page structure

### overview
- Two rows of 6 equal-width KPI cards
- Anomaly warning table
- Headcount distribution card with data bars
- Bottom chart area

### recruit
- 7 KPI cards including onboarded count
- Special recruiting board in a 4-column grid: funnel + 3 special-topic panels
- Talent quality analysis block with KPI summary and charts

### product
- Independent tab
- Left: product-line comparison chart
- Right: scrollable product-line detail table with sticky header and 480px+ equal-height behavior
- Bottom: P4 special section

### manage
- Permission instructions
- Export section
- Offer list with add button
- Demand list with add button

## Layout rules
- `overview` and `manage` do not show the business-group filter bar.
- Keep page switching tied to `switchPage(name, el)`.
- Preserve lazy chart rendering by page.
- Preserve product-page equal-height handling and table scrolling.
