# Data and Charts Reference

## Core data domains
- `headcount`: total people, staffing mix, attrition, monthly net change, overseas onboarded
- `recruit`: total demand, completed count, offer count, joined count, pending join, rejected, A-class and overseas subsets
- `offerList`: offer detail table
- `demandList`: recruiting demand detail table
- `products`: business-group and product-line progress, including P4 fields
- `anomaly`: warning table rows

## Stable data rule
- Overseas onboarded count follows: manual entry first, fallback to `offerList` rows where `overseas === '是'` and `status === '已入职'`.

## Chart and render behavior
- Use ECharts 5.
- Reuse chart instances instead of recreating them unnecessarily.
- Render charts lazily by page.
- On the product page, after page switch or filter change, refresh both table and chart height.

## Export behavior
- Header button `page-export-btn` exports the current page CSV.
- Page mapping:
  - `overview` → overview CSV
  - `recruit` → recruit CSV
  - `product` → product-page CSV
  - `manage` → all-data CSV
- Manage-page category exports include:
  - offer list
  - demand list
  - product data
  - headcount data
  - all data
- Product-page export must follow the current business-group filter.
- Main interaction is CSV export; JSON may remain as auxiliary logic but is not the primary user path.

## Tables
- Offer table and demand table support keyword search and multi-dimensional filtering.
- Product detail table is scrollable and must keep sticky headers.

## Permission model
- No login wall.
- Page opens directly in read-only mode.
- Editing requires password verification inside the current session.
