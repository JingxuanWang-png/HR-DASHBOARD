# Maintenance and Share Reference

## File map
- Main dashboard: `/Users/ara/WorkBuddy/20260330182034/hr_dashboard.html`
- Share dashboard: `/Users/ara/WorkBuddy/20260330182034/hr_dashboard_share.html`
- Project skill root: `/Users/ara/WorkBuddy/20260330182034/.workbuddy/skills/hr-dashboard/`

## Edit strategy
- Prefer modifying `hr_dashboard.html` in place.
- Keep `hr_dashboard_share.html` identical after every functional change.
- Use the project skill as the stable source of conventions; do not treat temporary experiments as the standard.

## Validation checklist
- Check inline script syntax after JavaScript changes.
- Confirm page switching, chart rendering, table rendering, and export behavior.
- Confirm main and share files are identical after sync.
- Preview the HTML result before handoff.

## Packaging
- Validate or package the skill with the built-in `skill-creator` scripts when distribution is needed.
- Project-level install path: `.workbuddy/skills/hr-dashboard/`
- User-level install path if cross-project reuse is needed: `~/.workbuddy/skills/hr-dashboard/`

## Share upload
Use the established 72-hour upload flow:

```bash
curl -F "reqtype=fileupload" -F "time=72h" -F "fileToUpload=@hr_dashboard_share.html" https://litterbox.catbox.moe/resources/internals/api.php
```

## Current sharing note
- Latest known 72-hour link during this session: `https://litter.catbox.moe/3zjbh1.html`
- If the link expires, upload again instead of editing the old URL.
